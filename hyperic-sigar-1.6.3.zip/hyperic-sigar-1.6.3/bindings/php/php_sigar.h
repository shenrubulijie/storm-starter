#ifndef PHP_SIGAR_H
#define PHP_SIGAR_H 1

extern zend_module_entry sigar_module_entry;

#endif
